import { Component, OnInit } from '@angular/core';
import data from '../../walletdata/wallet.json';
@Component({
  selector: 'app-viewwallet',
  templateUrl: './viewwallet.component.html',
  styleUrls: ['./viewwallet.component.css']
})
export class ViewwalletComponent implements OnInit {
  array=data
  flag=false
  constructor() { }

  ngOnInit() {
  }
  setFlag()
  {
    this.flag=true
  }
}
