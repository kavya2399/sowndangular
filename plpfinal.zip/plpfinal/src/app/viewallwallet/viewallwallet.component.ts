import { Component, OnInit } from '@angular/core';
import data from '../../walletdata/wallet.json';
@Component({
  selector: 'app-viewallwallet',
  templateUrl: './viewallwallet.component.html',
  styleUrls: ['./viewallwallet.component.css']
})
export class ViewallwalletComponent implements OnInit {
  array=data
  constructor() { }

  ngOnInit() {
  }

}
