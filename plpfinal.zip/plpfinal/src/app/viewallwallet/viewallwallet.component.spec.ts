import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewallwalletComponent } from './viewallwallet.component';

describe('ViewallwalletComponent', () => {
  let component: ViewallwalletComponent;
  let fixture: ComponentFixture<ViewallwalletComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewallwalletComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewallwalletComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
