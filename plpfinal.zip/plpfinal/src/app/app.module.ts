import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddamountComponent } from './addamount/addamount.component';
import { HomeComponent } from './home/home.component';
import { ViewwalletComponent } from './viewwallet/viewwallet.component';
import { ViewallwalletComponent } from './viewallwallet/viewallwallet.component';
import { MoneytransferComponent } from './moneytransfer/moneytransfer.component';
import { WalletaccountComponent } from './walletaccount/walletaccount.component';
import { FilterPipe } from './filter.pipe';

@NgModule({
  declarations: [
    AppComponent,
    AddamountComponent,
    HomeComponent,
    ViewwalletComponent,
    ViewallwalletComponent,
    MoneytransferComponent,
    WalletaccountComponent,
    FilterPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
