import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {AddamountComponent} from '../app/addamount/addamount.component';
import {HomeComponent} from '../app/home/home.component';
import {MoneytransferComponent} from '../app/moneytransfer/moneytransfer.component';
import {ViewallwalletComponent} from '../app/viewallwallet/viewallwallet.component';
import {ViewwalletComponent} from '../app/viewwallet/viewwallet.component';
import {WalletaccountComponent} from '../app/walletaccount/walletaccount.component';
const routes: Routes = [
  {
    path: '',
    component: HomeComponent
  },
  {
    path: 'wallet',
    component: WalletaccountComponent
  },
  {
    path: 'viewwallet',
    component:ViewwalletComponent
  },
  {
    path: 'addamount',
    component:AddamountComponent
  },
  {
    path: 'moneytransfer',
    component:MoneytransferComponent
  },
  {
    path: 'viewall',
    component:ViewallwalletComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
